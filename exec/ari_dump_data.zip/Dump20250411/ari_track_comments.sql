-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: j12c205.p.ssafy.io    Database: ari
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `track_comments`
--

DROP TABLE IF EXISTS `track_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `track_comments` (
  `track_comment_id` int NOT NULL AUTO_INCREMENT,
  `content` varchar(500) NOT NULL,
  `content_timestamp` varchar(5) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `deleted_yn` tinyint(1) NOT NULL DEFAULT '0',
  `member_id` int NOT NULL,
  `track_id` int NOT NULL,
  PRIMARY KEY (`track_comment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `track_comments`
--

LOCK TABLES `track_comments` WRITE;
/*!40000 ALTER TABLE `track_comments` DISABLE KEYS */;
INSERT INTO `track_comments` VALUES (1,'차려오너라~','0:02','2025-04-09 14:43:47.735660',0,2,1),(2,'최고!','0:09','2025-04-09 15:00:42.856652',0,2,1),(3,'와우','0:09','2025-04-09 15:01:14.049358',0,2,1),(4,'중독성 최고!??','0:03','2025-04-09 15:15:57.624600',0,2,1),(5,'도입부터 확실히 다르다','0:04','2025-04-09 17:53:46.736616',0,13,36),(6,'도입부터 확실히 다르다','0:04','2025-04-09 17:53:52.867815',0,13,36),(7,'저는 이 부분에서 갑자기 조용해지는 게 신의 한수라고 생각합니다','1:31','2025-04-09 17:56:15.946942',0,13,27),(8,'가리나 폼 미쳤네','0:10','2025-04-10 14:34:04.095062',0,2,2),(9,'이 부분 좋아요','0:47','2025-04-10 21:14:09.146068',0,13,41),(10,'공부하면서 듣기좋음','0:37','2025-04-10 21:35:37.886872',0,2,27),(11,'나 이재용인데 이거 싫다는 사람 못 봄','1:00','2025-04-10 21:38:37.109678',0,2,1),(12,'INNER PEACE?‍♂️','0:10','2025-04-10 21:43:50.382202',0,2,39),(13,'wow,,','1:49','2025-04-10 21:51:23.363234',0,21,39),(14,'나 이재용인데 이거 싫다는 사람 못 봄','1:00','2025-04-10 22:36:08.218343',0,2,1),(15,'이 부분 참 좋다','1:37','2025-04-11 09:25:29.176324',0,4,50),(16,'후렴구 좋아요','2:45','2025-04-11 09:25:55.084962',0,4,50);
/*!40000 ALTER TABLE `track_comments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 11:58:31
