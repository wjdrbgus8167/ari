-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: j12c205.p.ssafy.io    Database: ari
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fantalks`
--

DROP TABLE IF EXISTS `fantalks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fantalks` (
  `fantalk_id` int NOT NULL AUTO_INCREMENT,
  `content` varchar(1000) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `fantalk_channel_id` int NOT NULL,
  `fantalk_image_url` varchar(2000) DEFAULT NULL,
  `member_id` int NOT NULL,
  `track_id` int DEFAULT NULL,
  PRIMARY KEY (`fantalk_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fantalks`
--

LOCK TABLES `fantalks` WRITE;
/*!40000 ALTER TABLE `fantalks` DISABLE KEYS */;
INSERT INTO `fantalks` VALUES (1,'변기 앞에서 시크하게','2025-04-09 15:00:01.268312',7,'https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/fantalk/images/b2009716-d1e8-43d5-a03b-4d5e103875ad.png',7,NULL),(2,'자다 일어나 찍은 척','2025-04-09 15:00:38.879171',7,'https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/fantalk/images/c5c1a81c-39c1-4a84-adf9-ed35e64485bd.png',7,NULL),(3,'봄을 맞아 새로운 통기타 하나를 샀어요 ㅎㅎ','2025-04-09 15:02:27.599269',4,'https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/fantalk/images/d7b37ab7-89b9-4ff4-93bd-f70cdeb89312.jpg',4,NULL),(4,'날씨가 선선하니 기타 치기 좋은 날씨네요','2025-04-09 15:04:41.720138',4,NULL,6,NULL),(5,'항상 Rikas님의 좋은 노래로 위로 받고 있어요 ㅎㅎ','2025-04-09 15:07:39.503585',4,NULL,2,26),(6,'안녕하세요 ㅎ.ㅎ 저도 예전에 캐릭캐릭체인지 엄청 좋아했어서 노래 들어봤는데 너무 좋아서 구독했어요 !!!\n\n이건 제 수호알 쿠션이에요 귀엽죠','2025-04-09 16:04:49.032524',12,'https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/fantalk/images/ce0cff2b-7702-4923-95f3-6ffd9a1ac18a.jpg',13,NULL),(7,'안녕하세요 여러분!! 팬톡에 글을 남기는 건 처음이네요. 앞으로 많이 자주 소통하겠습니다!\n\n저는 오늘 인터뷰 하고 왔어요 ㅎ','2025-04-11 04:21:31.721430',4,'https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/fantalk/images/227fe1e9-0455-49d5-b0b0-a71ca0cb16d1.jpg',4,NULL),(8,'오늘의 추천곡! city of galaxy ??\n제 신곡이에요 하하','2025-04-11 04:27:21.216856',4,NULL,4,48);
/*!40000 ALTER TABLE `fantalks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 11:58:34
