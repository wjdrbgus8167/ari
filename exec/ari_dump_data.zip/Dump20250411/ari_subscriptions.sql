-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: j12c205.p.ssafy.io    Database: ari
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `subscription_id` int NOT NULL AUTO_INCREMENT,
  `activate_yn` bit(1) NOT NULL DEFAULT b'1',
  `expired_at` datetime(6) DEFAULT NULL,
  `member_id` int NOT NULL,
  `subscribed_at` datetime(6) NOT NULL,
  `subscription_plan_id` int NOT NULL,
  PRIMARY KEY (`subscription_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES (1,_binary '',NULL,2,'2025-04-09 13:37:27.482315',1),(2,_binary '',NULL,6,'2025-04-09 13:42:42.247733',1),(3,_binary '',NULL,6,'2025-04-09 13:43:58.477767',2),(4,_binary '',NULL,8,'2025-04-09 13:48:27.282998',1),(5,_binary '',NULL,8,'2025-04-09 13:54:58.226191',3),(6,_binary '',NULL,8,'2025-04-09 13:56:13.253176',4),(7,_binary '',NULL,9,'2025-04-09 13:58:42.242824',1),(8,_binary '',NULL,2,'2025-04-09 14:08:13.204483',4),(9,_binary '',NULL,2,'2025-04-09 14:34:13.167276',2),(10,_binary '',NULL,11,'2025-04-09 14:40:27.170241',1),(11,_binary '',NULL,13,'2025-04-09 15:45:57.451762',1),(12,_binary '',NULL,13,'2025-04-09 15:46:00.177553',5),(13,_binary '',NULL,14,'2025-04-09 17:32:37.598229',1),(14,_binary '',NULL,17,'2025-04-10 11:06:13.525132',1),(15,_binary '',NULL,4,'2025-04-11 01:20:40.461781',4);
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 11:58:37
