-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: j12c205.p.ssafy.io    Database: ari
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notices`
--

DROP TABLE IF EXISTS `notices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notices` (
  `notice_id` int NOT NULL AUTO_INCREMENT,
  `artist_id` int NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `deleted_yn` tinyint(1) NOT NULL DEFAULT '0',
  `notice_content` varchar(2000) NOT NULL,
  `notice_image_url` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`notice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notices`
--

LOCK TABLES `notices` WRITE;
/*!40000 ALTER TABLE `notices` DISABLE KEYS */;
INSERT INTO `notices` VALUES (1,5,'2025-04-09 13:50:22.471861',0,'하이 아가리들!',NULL),(2,1,'2025-04-09 14:01:54.319625',0,'yo 철가루들\n철철이 새 EP 나온다\n제목은 [철들지마]\n4월 20일 오후 6시, 전 음원 플랫폼 박제\n\n다음 날, 21일 저녁 7시\n합정 C-CLUB에서 쇼케이스 땅땅\n제목은 “철들긴 글렀SHOW”\n티켓은 4월 10일 인터파크에서 딱 열려\n\n현장 오면 뭐 있다\n철철이 손으로 직접 꼰 굿즈 하나\n선착순임 묻지도 따지지도 말고 와\n\n진짜 이번엔 철가루들 없으면 심심하니까\n전원 출석 체크함\n끝',NULL),(3,9,'2025-04-09 14:07:24.897407',0,'안녕하세요 여러분들!! 토니 베넷입니다ㅎㅎ 요즘 일교차가 심해서 감기 걸리기 좋은 날씨인거 같아요... 항상 건강 조심하시고 오늘 저녁에 새로운 앨범이 발매되니 기대해주세요!! 저의 이번 앨범은 정말 고뇌를 많이 한 결과물입니다ㅠㅠ','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/notice/images/2e96ea0b-86c8-4270-b10e-f88c69059931.png'),(4,4,'2025-04-09 15:00:14.956213',0,'안녕하세요, Rikas입니다.\n\n요즘 잘 지내고 계시죠?\n바람이 조금씩 따뜻해지고 있네요.\n그런 계절에 맞춰, 작은 앨범 하나를 준비했어요.\n제목은 \"Barefoot Sundays\" —\n그냥, 아무것도 하지 않아도 좋은 일요일 같은 앨범입니다.\n너무 시끄러운 하루 끝에 조용히 들어주셨으면 좋겠어요.\n\n곧 작은 공연도 준비해서 알려드릴게요.\n항상 고맙고, 조만간 얼굴 보면서 인사드릴 수 있길 바랍니다.\n\n– Rikas 드림.',NULL),(5,12,'2025-04-09 16:07:46.896403',0,'여러분 안녕하세요! 처음 인사드리네요.\n저희 캐릭체인 밴드는 캐릭캐릭체인지를 좋아하는 사람들이 모여 만들어진 밴드입니다. \n\n이번에 앨범 냈는데 많이 들어주세요! <밤이 우릴 기억할까>','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/notice/images/86af43e8-afe6-4a46-80a6-6ac97ac03413.png'),(6,11,'2025-04-09 17:47:36.045589',0,'안녕하세요 괴도키드밀리입니다ㅎㅎ... 최근 잦은 밤샘으로 인해 몸 상태가 상당히 안좋아진 상황입니다... 그래서 당분간 작업을 못할 것 같아 미리 이렇게 공지드리게 되었습니다. 물론 그 전에 작업한 작업물이 빠른 시일 내에 올라 갈테니 많은 관심 부탁드립니다!! 빠르게 회복해서 빠른 시일 내에 다시 돌아오겠습니다....','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/notice/images/fad1b68b-bfe2-4f38-be87-d054db616646.png'),(7,16,'2025-04-10 11:42:13.742714',0,'여러분 제 노래 많이 들어주세요..!',NULL),(8,16,'2025-04-10 11:44:31.440660',0,'여러분 저 어제 인터뷰 했어요! 많관부','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/notice/images/7e1bc423-22ea-4725-8d65-d27a6b8c4501.jpg'),(9,13,'2025-04-10 21:01:46.664262',0,'공지라고 하기는 뭐하지만.. 캐릭체인 밴드 팬입니다 ?',NULL);
/*!40000 ALTER TABLE `notices` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 11:58:28
