-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: j12c205.p.ssafy.io    Database: ari
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members` (
  `member_id` int NOT NULL AUTO_INCREMENT,
  `bio` varchar(100) DEFAULT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `email` varchar(64) NOT NULL,
  `instagram_id` varchar(20) DEFAULT NULL,
  `nickname` varchar(100) NOT NULL,
  `password` varchar(64) NOT NULL,
  `profile_image_url` varchar(2000) DEFAULT NULL,
  `provider` varchar(10) DEFAULT NULL,
  `registered_at` datetime(6) NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES (1,'간지 나는 힙합 인생',NULL,'kjm@gmail.com','@kangzichulchul','강지철철','$2a$10$.EYd.Wa//5vsE/iJ445G.uBs3TVAY.TOgGrRZMdcBuIygxm9Ypdy.','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/mypages/images/0eeb2172-d91e-4b92-9bda-749761f883c7.jpg','','2025-04-09 13:33:37.202255'),(2,'King 너희 나 절대 못 이겨',NULL,'kingkang@gmail.com','kingkang85','kingkang','$2a$10$lYJPgCY7KBE.da1UGGQuYuTDuPIqM0B3.b1IQQz4HzJYHcs3kk/Rq','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/mypages/images/9a071811-980b-48c8-9431-11f3c19288fe.png','','2025-04-09 13:33:51.291528'),(3,NULL,NULL,'cha@gmail.com',NULL,'캐릭캐릭 밴드','$2a$10$2HNWuVEomefoegTmm6XwG.xk8dO1KVA6P2/sTSXjBrBSdaZCD1dCW',NULL,'','2025-04-09 13:36:35.516209'),(4,'낭만.. 기타.. 음악',NULL,'qwer@naver.com','jinlal','Rikas','$2a$10$vvsRGWZ3yKMoxz4cYLVluOI8GiO6JcHrs0S9ht9/rxqQ9dtdLyq4C','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/mypages/images/51d6a137-09b3-4a03-8277-91ddd86f1e14.jpg','','2025-04-09 13:37:03.436527'),(5,'아가리단에 입단해라',NULL,'a@a.com','','가리나','$2a$10$ZnMa0ZvfwbDYsePxcT.xhenh2YzsVVSz3gjDjX1yyumFjZ0d85NPW','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/mypages/images/b1c5f7a1-4261-4cb3-a843-830dd652cee2.jpg','','2025-04-09 13:39:15.850853'),(6,'ㅋㅋ',NULL,'qwer@gmail.com','','1234','$2a$10$ikz//kStbWSGhGl0vtcfsObfkTVK5dRD9PqH2upxSKNOlnzQeiATC','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/mypages/images/bb67fc92-ab29-4eb2-9d60-08990da841bc.jpg','','2025-04-09 13:39:27.465867'),(7,'안녕하세요 수민입니다.',NULL,'sumin@gmail.com','suminboutu','SUMIN','$2a$10$767jliKz/LPj/hbKm8L6bOnFvzZMJlFfWl6jNlIHyQuIlKNszDWPu','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/mypages/images/b76d60f3-72d0-40ba-b349-c8b604556709.jpg','','2025-04-09 13:40:45.684195'),(8,NULL,NULL,'kamisama@gmail.com',NULL,'오마이카미사마','$2a$10$KYRXjHpFzwSZTkm/KkICO.arn6D5sZIIkYLlnNNuQwAcb7U6f97BW',NULL,'','2025-04-09 13:45:32.047088'),(9,'안녕하세요. 재즈 가수 토니 베넷입니다.',NULL,'rbgus8167@gmail.com','tonny_b','토니 베넷','$2a$10$qTIsOtLZJyjn9uPT9SfLm.GwQdnaGIsgaSh4RrVZztBkFtnGNrCFC','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/mypages/images/a203feb7-a50b-4d2b-ad9f-9dd6b3dd74cd.png','','2025-04-09 13:47:44.890264'),(10,NULL,NULL,'hump@gmail.com',NULL,'HUMP','$2a$10$q7h9UNJ51/dFPN6WD9l20uFsmyq2Sjv2GaU44yjT3oE13lPuv7jxe',NULL,'','2025-04-09 14:14:04.258068'),(11,'힙합과 알앤비를 넘나드는 프로듀서이자 아티스트입니다ㅎㅎ',NULL,'wjdrbgus8167@gmail.com','Phantom_thief99 ','괴도키드밀리','$2a$10$g99LKtxdgNkDEMuuInL7Vu4xwqIOx4qBsVSOJRT2FMBxXKy7guOBy','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/mypages/images/e85e9038-23f3-40f8-abb8-89f7114c03b2.jpg','','2025-04-09 14:14:29.100480'),(12,'캐캐체를 좋아하는 사람들이 모여 탄생한, 캐릭체인 밴드입니다',NULL,'c@gmail.com','chaavv','캐릭체인 밴드','$2a$10$fmkrxMrSpoOAFVmttSexVeEUHXqFwhycXDRqu.nhwH8I8bPlBdz4e','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/mypages/images/2b7f82f1-9cdd-4100-b21d-4a499992cd07.png','','2025-04-09 14:29:23.403104'),(13,NULL,NULL,'n@gmail.com',NULL,'권남희','$2a$10$xA13yWXfEByi0R2gGp1CLuMETGomnlxzRCavUN.6szRiXB3DGBYmq',NULL,'','2025-04-09 14:59:59.781441'),(14,NULL,NULL,'rbgus@gmail.com',NULL,'독규현','$2a$10$Z0G.JMKCULYJfAntg14jReTMXyxVL8mUjLbXxJFqXfnYNVc6oJd5.',NULL,'','2025-04-09 17:23:49.944069'),(15,NULL,NULL,'l@gmail.com',NULL,'라일리','$2a$10$t9K4vQP74LivgW0FFPdW.u2T/2WV2xHKCMDyp9lPnB8oYXUn9zlTC',NULL,'','2025-04-09 17:26:53.693743'),(16,NULL,NULL,'rikas@gmail.com',NULL,'리카스','$2a$10$SRUCZ2lpSO3WTFxXHj3WquTtM/erVxKWMR1CjJOhk3gRbW.6o7icS',NULL,'','2025-04-10 10:10:30.488288'),(17,NULL,NULL,'k@gmail.com',NULL,'김준stone','$2a$10$XNefVmH0o.aD4jW5lChEReOwOBYkjjhAD5.FoycBELhVyxgfpC8uC',NULL,'','2025-04-10 10:24:07.343946'),(18,NULL,NULL,'test1234@gmail.com',NULL,'test1234','$2a$10$ruq5LoJifFnoehb1FXOn.ehYcFLClirHZBCug4jP/9H/RfMZKrFWa',NULL,'','2025-04-10 10:28:06.718507'),(19,NULL,NULL,'test1@naver.com',NULL,'test1','$2a$10$EyY3mI9varJD5YD3L0uZpOAWItJRTwhoJGog5ne0ei1s.qOxbXkPW',NULL,'','2025-04-10 13:54:33.421284'),(20,'알앤비하는 문수진입니다.',NULL,'moon@gmail.com','moonsujin94','Moon','$2a$10$AO2sDTv.Vls8IEo8pABicOKzdX0lgzD21Qh9f9lXdXysab0mkjVxK','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/mypages/images/d7adf7fc-f677-4d74-a158-96b69a4847c2.png','','2025-04-10 16:19:28.228160'),(21,NULL,NULL,'alslvls1995@naver.com',NULL,'사리','$2a$10$lvGwdKjXndiYnKV/ECzgqu40hghj3QYXNyOT/aXch.T10385SNedi',NULL,'','2025-04-10 21:45:59.513531');
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 11:58:29
