-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: j12c205.p.ssafy.io    Database: ari
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `albums`
--

DROP TABLE IF EXISTS `albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `albums` (
  `album_id` int NOT NULL AUTO_INCREMENT,
  `album_like_count` int DEFAULT '0',
  `album_title` varchar(200) NOT NULL,
  `cover_image_url` varchar(2000) NOT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `released_at` datetime(6) NOT NULL,
  `genre_id` int DEFAULT NULL,
  `member_id` int DEFAULT NULL,
  PRIMARY KEY (`album_id`),
  KEY `FKgo1exs517g8n9osc20m3qidib` (`genre_id`),
  KEY `FKoa2apgufgwr43eqly5c1sa1x7` (`member_id`),
  CONSTRAINT `FKgo1exs517g8n9osc20m3qidib` FOREIGN KEY (`genre_id`) REFERENCES `genres` (`genre_id`),
  CONSTRAINT `FKoa2apgufgwr43eqly5c1sa1x7` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `albums`
--

LOCK TABLES `albums` WRITE;
/*!40000 ALTER TABLE `albums` DISABLE KEYS */;
INSERT INTO `albums` VALUES (1,1,'HamKing','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/cover2e9527f3-b7ae-47f4-aafd-eb6a4cfafd36.jpg','햄버거처럼 꽉 찬 힙합.\n두툼한 비트, 녹아내리는 라임, 바삭한 플로우.\n우린 주방이 아니라 무대에서 굽는다.\n먹지 말고, 들어.','2025-04-09 13:44:27.660087',1,1),(2,1,'Eight ton truck','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/coverf752c62b-369e-41e3-a8f8-073b1f146ec8.jpg','고장난 8톤트럭처럼 힙합신에 등장한 가리나의 첫번째 미니앨범','2025-04-09 13:47:43.790484',1,5),(3,1,'그녀와 헤어진 곳은 운천호수 앞 벚꽃나무 ','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/cover17835c5b-0b21-4108-b9aa-6c8f50605eef.jpg','\"그녀와 헤어진 곳은 운천호수 앞 벚꽃나무\"는 이별과 추억이 교차하는, 그리움이 가득한 음악 앨범입니다. 벚꽃이 만개한 그 순간처럼, 사랑의 아픔과 아름다움이 담겨 있는 이 앨범은 시간 속에 묻히지 않는 특별한 기억들을 노래합니다. 헤어진 자리에서 다시 피어나는 벚꽃처럼, 잊을 수 없는 감정들이 노래마다 깊이 새겨져 있습니다. 각 곡은 잃어버린 것들과 다시 만날 수 없는 순간들을 향한 애절한 마음을 담고 있습니다.\n\n','2025-04-09 13:59:59.717854',2,5),(4,1,'My Crew','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/cover2acc94e7-24b9-41ac-9036-511e82e63c10.jpg','스트리트 감성과 리얼리티를 그대로 담은 힙합 앨범 MY CREW는 각자의 색깔을 가진 멤버들이 모여 만든 단단한 팀워크의 결과물. 거칠지만 진솔한 가사, 묵직한 비트 위에 얹은 생생한 이야기들이 리스너의 가슴을 울린다. 지금 바로, 우리 크루의 세계로 들어와.','2025-04-09 14:01:14.151342',1,1),(6,0,'재즈란 말이죠','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/covere44e057c-fede-4533-b4a7-079a567657fc.png','그는 노래하지 않는다. 속삭인다.\n토니 베넷의 목소리는 오래된 와인처럼, 해가 지고 나서야 진짜 맛을 보여준다.\n듣고 있으면 마음이 따뜻해지는 게 아니라, 시간을 거슬러 올라가는 느낌이 든다.\n재즈를 좋아하는 사람들에게 이 앨범을 바친다.','2025-04-09 14:05:34.855861',3,9),(7,2,'YOUR HOME','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/cover690f4052-92b6-4dad-ad81-f9d36eeada4a.png','사랑이라는 감정과 소재를 세상에서 가장 특별하게 표현해낸 앨범 = Your Home = 너의 ‘마음’. 그리고 ‘사랑’.\n \n수민(SUMIN)은 ‘사랑’이라는 주제 아래 ‘애정’, ‘애증’,’ 화’, ‘이끌림’, ‘다름’, ‘관능’ 등의 다채로운 면들을 이 앨범에 담아냈고 그녀의 고향 도시 ‘서울’의 매력을 이야기했다. 80년대 Synth Pop 사운드부터 Hip-hop, PB R&B, EDM 등 장르를 넘나드는 그녀의 이번 앨범은 이 다음 앨범의 방향성에 대해 궁금증을 증폭시킨다.\n또한 선공개 곡 ‘설탕분수 (Prod.Pomrad)’ 뮤직비디오에 이어, 공개된 ‘너네 집 feat.Xin Seha)’ 뮤직비디오에서는 수민(SUMIN) & 신세하(Xin Seha)가 함께 출연하여 강렬하고, 아름답고, 신비로운 장면들을 연출해냈다.\n \n피쳐링에 참여한 국내 유일무이 뉴웨이브, 신스팝을 기반으로 다양한 음악을 선보이는 아티스트 신세하(Xin Seha)와 발표하는 곡마다 자신의 고찰과 가치관을 시원하게 풀어내는 래퍼 쿤디판다(Khundi Panda)가 참여했으며, 벨기에 출신 천재 프로듀서 Pomrad, 그리고 자신만의 과감한 사운드를 만들어 수많은 아티스트에게 사랑받고있는  SuperFreak Records 소속 프로듀서 비앙(Viann)이 함께했다.\n \n그리고 술탄 오브 더 디스코(Sultan Of The Disco), 나잠수와 빅웨이브즈(NahzamSue with Big Waves)의 멤버 나잠수가 전곡 마스터링작업에 참여해 이번 SUMIN의 정규앨범에 큰 생동감을 불어넣었다.\n마지막으로 풍성하고 강렬한 색과 3D 작업이 돋보이는 [Your Home]의 아트웍은 Nell, Jinbo, Dean, Crush, 박재범 등 수많은 뮤지션의 앨범 아트웍을 담당했던 레어버스(Rarebirth)가 함께했다.','2025-04-09 14:09:24.391190',5,7),(8,1,'NO CHILL \'TIL SUNRISE','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/cover686b1c4f-591b-4d7d-8571-a7efdb346090.jpg','Night drives, cheap liquor, and too many thoughts.\nThis album ain’t about the come-up, it’s about surviving the in-between.\nCold verses, late-night confessions, no filters.\nJust HUMP being HUMP.','2025-04-09 14:22:00.617670',1,10),(9,0,'Barefoot Sundays','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/cover6a44fe1b-14a3-40e8-9a0e-115f6d2aa5dc.jpg','일요일 아침, 맨발로 걷는 공기 같은 노래들.\n바쁘게 살아온 우리에게 잠깐의 숨을 틔워주는 시간.\n소박한 멜로디, 솔직한 이야기, 그리고 아무것도 하지 않아도 괜찮다는 위로.','2025-04-09 14:55:39.410058',2,4),(10,0,'밤이 우리를 기억할까','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/coverd95689fd-758f-4bd5-8553-06a25ed35cf8.jpg','예전의 저를 떠올리며 만든 노래입니다.\n\n그때의 저를 살고 있는 누군가에게 힘이 되었으면 좋겠어요.\n\n날씨 좋을 때 햇빛 아래서 들어주세요. 감사합니다.','2025-04-09 14:59:17.200200',4,12),(11,1,'Kaito KidMilli','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/cover80fe6c65-5266-49ad-9f69-d50e66bac93a.jpg','괴도키드밀리의 첫 정규 앨범이다. 감각적이고 세련된 힙스러움이 과하지 않고 듣는 이로 하여금 자연스럽게 그루브를 탈 수 있는 정도이다. ','2025-04-09 15:29:47.836609',1,11),(12,1,'In Between the Night','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/coverb368575b-5285-4f7b-9ef3-464b7a2347d6.jpg','괴도키드밀이의 첫 정규 앨범 발매 이후 첫 프로듀서로 참여한 앨범이다.','2025-04-09 15:42:45.567984',5,11),(13,0,'3AM','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/cover16293209-6795-4a89-b24d-e22238735c77.png','하루의 끝, 모든 것이 잠든 시간.\n그 고요한 틈 사이, 마음이 가장 솔직해지는 순간이 있다.\n\n재즈 보컬리스트 권남희의 첫 앨범 3AM은\n깊은 밤, 도시의 작은 재즈 클럽에서 흐를 법한 세 곡으로\n듣는 이의 감정에 조용히 말을 건넨다.\n\n햇살처럼 부드러운 Orchard Way,\n따스한 위로를 담은 What A Day,\n그리고 클럽의 은은한 공기를 닮은 Jazz at Mladost Club까지—\n\n당신의 3AM엔 어떤 음악이 흐르고 있나요?','2025-04-09 16:36:46.595087',3,12),(14,0,'떴다 떴다 비둘기','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/cover1e758001-21f9-45c3-95dd-2ee057578e75.jpg','비둘기를 관찰하며 날기를 고대하는 현대인의 마음을 담고 있다.','2025-04-09 16:40:19.438822',2,4),(15,1,'벚꽃나무 앞에서','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/coverf3d36181-4ccd-4e54-a668-f2d546c297eb.jpg','벚꽃나무 앞에서 너를 생각하며...','2025-04-10 10:22:38.685093',2,16),(16,1,'Baby PLZ','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/coveradc33c31-5929-4f18-8608-045883873530.png','아티스트 문수진의 한계는 과연 어디까지일까?\n이번엔 또 어떤 이야기를 가져왔을까?\n나는 누구인가?\n여긴 어디인가?','2025-04-10 16:25:10.000625',5,20),(17,1,'Starry','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/coveref07149b-98af-4592-9473-91191a38d621.png','별은 빛난다.\n우주도 빛난다.\n\n당신도 빛나는가?','2025-04-10 16:27:56.363998',5,20),(18,0,'Galaxy','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/coverf5513373-7dbc-4a3a-89e5-ff8cc0847b42.jpg','도시의 시간이 멈춘 순간, 아스팔트 위에 별들이 내려앉았다. 네온사인과 별빛이 뒤섞인 이 밤의 풍경은 현실과 환상의 경계를 허문다. 이 앨범은 반짝이는 도시의 밤하늘 아래, 평범했던 일상이 특별한 모험으로 변모하는 순간을 포착했다. 복잡한 골목길은 우주의 미지로, 지친 발걸음은 별들 사이의 춤으로 탈바꿈한다. 공간의 제약에서 벗어나 무한한 가능성을 품은 \'우리만의 우주\'로 당신을 초대한다.','2025-04-10 23:57:08.956459',5,1),(19,0,'Gloomy Night','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/cover1ff03b0e-d316-4a70-887b-f3ed95ff90b7.jpg','도시의 밤과 네온 불빛 사이에서 펼쳐지는 마법 같은 이야기. 익숙한 일상을 벗어나 별빛이 내려앉은 골목길을 걷다 보면 어느새 우리만의 작은 우주가 만들어져요. 분주한 도심 속에서도 찾을 수 있는 특별한 낭만과 자유로움을 담았어요. 이 음악과 함께라면 당신도 은하를 걷는 듯한 꿈같은 순간을 경험할 수 있을 거예요.','2025-04-11 00:04:17.758717',2,4),(20,0,'도시의 은하','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/cover72b38e55-d099-4229-98bb-5ab7a4b14843.png','도시의 시간이 멈춘 순간, 아스팔트 위에 별들이 내려앉았다. 네온사인과 별빛이 뒤섞인 이 밤의 풍경은 현실과 환상의 경계를 허문다. 이 앨범은 반짝이는 도시의 밤하늘 아래, 평범했던 일상이 특별한 모험으로 변모하는 순간을 포착했다. 복잡한 골목길은 우주의 미지로, 지친 발걸음은 별들 사이의 춤으로 탈바꿈한다. 공간의 제약에서 벗어나 무한한 가능성을 품은 \'우리만의 우주\'로 당신을 초대한다.','2025-04-11 00:41:26.477515',2,4),(21,0,'너의온사인','https://ari-205-bucket.s3.ap-northeast-2.amazonaws.com/album/cover81f6da13-ffea-4e8f-bb2b-c63943fa7a64.jpg','도시의 밤과 네온 불빛 사이에서 펼쳐지는 마법 같은 이야기. 익숙한 일상을 벗어나 별빛이 내려앉은 골목길을 걷다 보면 어느새 우리만의 작은 우주가 만들어져요. 분주한 도심 속에서도 찾을 수 있는 특별한 낭만과 자유로움을 담았어요. 이 음악과 함께라면 당신도 은하를 걷는 듯한 꿈같은 순간을 경험할 수 있을 거예요.','2025-04-11 01:11:21.292875',4,1);
/*!40000 ALTER TABLE `albums` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 11:58:24
